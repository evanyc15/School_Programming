//Evan Chen
//CIS35A
//Exercise1.1


package exercises;

public class Exercise1_1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{
			System.out.println("1. A Java method is called what in C/C++?\n");
			System.out.println("Answer #1: function\n");
			System.out.println("2. Java is compiled into___\n");
			System.out.println("Answer #2: .class file\n");
			System.out.println("The Java interpreter is called the____\n");
			System.out.println("Answer #3: Java Virtual Machine (JVM)\n");
			}

	}

}


/*1. A Java method is called what in C/C++?

Answer #1: function

2. Java is compiled into___

Answer #2: .class file

The Java interpreter is called the____

Answer #3: Java Virtual Machine (JVM)*/
