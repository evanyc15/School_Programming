//Evan Chen
//Exercise 7.3

package exercises;

public class Exercise7_3 {

public interface Comparable{
	public abstract int compareTo(Object temp);
}

}
