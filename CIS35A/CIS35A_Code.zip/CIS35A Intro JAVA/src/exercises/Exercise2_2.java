package exercises;

public class Exercise2_2 {
	public static void main(String[] args) {
	int inum1=5, inum2=8;

	while((inum1--)!=0){
	System.out.println(inum1);		
	}
	}
}
