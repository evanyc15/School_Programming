package homework;

public interface NumberGameInterface7 {
	public abstract void drawNumbers();
	public abstract void getResults();
	public abstract String displayResults();
}
